package com.green.bubuddies;

import java.util.ArrayList;
//Class for storing the current user's info and the chat with user's info
//Used by switching from Contacts list page to the actual Message page
public class UserDetails {
    static String username = "";
    static String chatwithid = "";
    static String chatwithname = "";
    static ArrayList<String> contacts = null;
    static String uid = "";
    static String selfpic = "";
    static String chatwithpic = "";
}